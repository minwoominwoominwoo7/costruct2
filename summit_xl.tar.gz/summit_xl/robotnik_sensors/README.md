# robotnik_sensors

Robotnik standard sensors description

# dependencies

To use Gazebo GPU accelerated simulation: https://github.com/RobotnikAutomation/velodyne_simulator
