^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package summit_xl_sim
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.1.3 (2018-05-15)
------------------
* removed summit_xl_control pkg
* solved package.xml sintax error
* Merge branch 'kinetic-devel' into kinetic-multirobot-devel
* Merge branch 'indigo-devel' into kinetic-devel
* summit_xl_sim: removed temp files
* 1.0.10

1.1.1 (2016-08-24)
------------------

>>>>>>> indigo-devel
1.0.10 (2016-08-24)
-------------------

1.0.9 (2016-07-13)
------------------

1.0.8 (2016-07-12)
------------------

1.0.7 (2016-07-12)
------------------

1.0.6 (2016-07-04)
------------------

1.0.5 (2016-07-01)
------------------

1.0.4 (2016-07-01)
------------------

1.0.3 (2016-07-01)
------------------

1.0.2 (2016-07-01)
------------------

1.0.1 (2016-06-28)
------------------
* Modified authors from package.xml
* Some spring cleaning
* fixed merge
* modified CMakeLists.txt and added urls and maintainers to package files
* Added maintainers
* Changed maintainer
* minor changes
* minor changes
* added authors, website and bugtracker
* Added dependencies to summit_xl_sim meta package
* fixing package dependencies
* 1.0.0
* Deleting summit_xl_joint_state. Creating summit_xl_sim metapackage
* Contributors: JorgeArino, carlos3dx, mcantero

* fixing package dependencies
* 1.0.0
* Deleting summit_xl_joint_state. Creating summit_xl_sim metapackage
* Contributors: JorgeArino
