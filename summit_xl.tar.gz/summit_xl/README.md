Stable branch used by The Construct before simulation update done in January 2019
